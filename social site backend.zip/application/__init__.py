from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_migrate import Migrate
from flask_bcrypt import Bcrypt
from flask_cors import CORS

app = Flask(__name__)
db = SQLAlchemy(app)
migrate = Migrate(app, db)
bcrypt = Bcrypt(app)
cors = CORS(app, resources={r"/*": {"origins": "*"}})
jwt = JWTManager(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:abcd@localhost:5432/flask_db'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///socialdata.db'
app.config['SECRET_KEY']='8eb7d7067ddaea5469f2149b'

from application import  routes